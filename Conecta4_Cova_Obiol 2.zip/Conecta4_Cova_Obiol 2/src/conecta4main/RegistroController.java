/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package conecta4main;

import connect4.Connect4;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class RegistroController implements Initializable {

    @FXML
    private TextField correoTextfield;
    @FXML
    private TextField usuarioTextfield;
    @FXML
    private Button registrarse;
    @FXML
    private Button cancelar;
    @FXML
    private DatePicker datePicker;
    @FXML
    private PasswordField passwordTexfield;
    @FXML
    private ImageView imagenView;
    @FXML
    private Button seleccionarImagen;
    
    private File archivoImagen;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                // Desactivar el botón al inicio
        registrarse.setDisable(true);

        // Validación en tiempo real
        ChangeListener<String> campoListener = (observable, oldValue, newValue) -> verificarCampos();
        usuarioTextfield.textProperty().addListener(campoListener);
        correoTextfield.textProperty().addListener(campoListener);
        passwordTexfield.textProperty().addListener(campoListener);

        datePicker.valueProperty().addListener((observable, oldValue, newValue) -> verificarCampos());

        // Validar nickname en tiempo real
        usuarioTextfield.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.trim().isEmpty()) {
                Connect4 connect4 = Connect4.getInstance();
                if (connect4.existsNickName(newValue)) {
                    usuarioTextfield.getStyleClass().add("error");
                } else {
                    usuarioTextfield.getStyleClass().remove("error");
                }
            }
            verificarCampos();
        });
    }
        

    @FXML
    private void botonRegistrarse(ActionEvent event) {
    String usuario = usuarioTextfield.getText();
    String email = correoTextfield.getText();
    String contraseña = passwordTexfield.getText();
    LocalDate fechaNacimiento = datePicker.getValue();
    String imagenPath = (archivoImagen != null) ? archivoImagen.getAbsolutePath() : "user.png";

    resetearEstilos();

    if (!camposValidos(usuario, email, contraseña, fechaNacimiento)) {
        return;
    }

    try {
        Connect4 connect4 = Connect4.getInstance();
        if (connect4.existsNickName(usuario)) {
            mostrarAlertas("Error", "El nombre de usuario ya está en uso. Por favor, elige otro.");
            return;
        }
        
        connect4.registerPlayer(usuario, email, contraseña, fechaNacimiento, 0);
        mostrarAlertas("Éxito", "Usuario registrado correctamente.");

        // Cambiar a la escena de login
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);

        // Obtener el Stage actual y cambiar la escena
        Stage stage = (Stage) registrarse.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException e) {
        mostrarAlertas("Error", "Ocurrió un error al registrar al usuario. Inténtalo de nuevo.");
    }
}

    @FXML
    private void botonCancelar(ActionEvent event) {
        cancelar.getScene().getWindow().hide();

    }

    @FXML
    private void botonDatePicker(ActionEvent event) {}
   
    
    @FXML
    private void actionSeleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar imagen");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg"));

        File selectedFile = fileChooser.showOpenDialog(seleccionarImagen.getScene().getWindow());
        if (selectedFile != null) {
            archivoImagen = selectedFile;
            imagenView.setImage(new Image(selectedFile.toURI().toString()));
        } else {
            mostrarAlertas("Advertencia", "No se seleccionó ninguna imagen.");
        }
    }


    @FXML
    private void botonSeleccionarImagen(ActionEvent event) {}
    

    private boolean camposValidos(String usuario, String email, String contraseña, LocalDate fechaNacimiento) {
        resetearEstilos();
        StringBuilder errores = new StringBuilder();
        boolean valido = true;

        if (usuario == null || usuario.isEmpty() || !usuarioValido(usuario)) {
            usuarioTextfield.getStyleClass().add("error");
            errores.append("- El nombre de usuario debe tener entre 6 y 15 caracteres.\n");
            valido = false;
        }
        if (email == null || email.isEmpty() || !emailValido(email)) {
            correoTextfield.getStyleClass().add("error");
            errores.append("- El correo electrónico no es válido.\n");
            valido = false;
        }
        if (contraseña == null || contraseña.isEmpty() || !contraseñaValida(contraseña)) {
            passwordTexfield.getStyleClass().add("error");
            errores.append("- La contraseña debe tener entre 8 y 20 caracteres, con mayúsculas, minúsculas, números y caracteres especiales.\n");
            valido = false;
        }
        if (fechaNacimiento == null ) {
            datePicker.getStyleClass().add("error");
            valido = false;
        }

        if (!valido) {
            mostrarAlertas("Error", errores.toString());
        }
        return valido;
    }



    private boolean usuarioValido(String usuario) {
        return usuario.matches("[a-zA-Z0-9_-]{6,15}");
    }

    private boolean emailValido(String email) {
        return email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
    }

    private boolean contraseñaValida(String contraseña) {
        return contraseña.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%&*()\\-+=]).{8,20}$");
    }

    private void mostrarAlertas(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null); 
        alert.setContentText(message);
        alert.showAndWait();
    }
    private void resetearEstilos() {
    usuarioTextfield.getStyleClass().remove("error");
    correoTextfield.getStyleClass().remove("error");
    passwordTexfield.getStyleClass().remove("error");
    datePicker.getStyleClass().remove("error");
}

    private void verificarCampos() {
        boolean camposCompletos = !usuarioTextfield.getText().trim().isEmpty()
                && !correoTextfield.getText().trim().isEmpty()
                && !passwordTexfield.getText().trim().isEmpty()
                && datePicker.getValue() != null;

        registrarse.setDisable(!camposCompletos); // Habilitar/deshabilitar el botón
        }

    public void setParentController(LoginController parentController) {
        this.parentController = parentController;
    }
    private LoginController parentController;

}
    

