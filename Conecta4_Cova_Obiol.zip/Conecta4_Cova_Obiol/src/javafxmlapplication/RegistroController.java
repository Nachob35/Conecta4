/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.*;
import javafx.scene.control.DatePicker;


/**
 * FXML Controller class
 *
 * @author juanignacioobiolgarcia
 */
public class RegistroController implements Initializable {

    @FXML
    private Label nombreUsuario;
    @FXML
    private Label nombreCorreo;
   
    @FXML
    private Label numContra;
    @FXML
    private Label nacimientoFecha;

  
    public void controladorRegistro() {
        
       
        String usuario = nombreUsuario.getText();
        String contraseña = numContra.getText();
        String correo = nombreCorreo.getText();
        LocalDate fecha = nacimientoFecha.getValue();
        
        //Validaciones
        if(usuario.isEmpty() || contraseña.isEmpty() || correo.isEmpty() || fecha == null){
        errorLabel.setText("Todos los campos son obligatorios");
        return;
        }
        
       
        
       
    }    
    
}
