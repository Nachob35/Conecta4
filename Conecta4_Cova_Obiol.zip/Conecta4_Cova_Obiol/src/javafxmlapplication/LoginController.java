/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class LoginController implements Initializable {

    @FXML
    private Button btInicio;
    @FXML
    private Button btRegistrarse;
    @FXML
    private Button btSalir;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void clickInicio(MouseEvent event) {
    }

    @FXML
    private void ActInicio(ActionEvent event) {
    }

    @FXML
    private void clickRegistrarse(MouseEvent event) {
    }

    @FXML
    private void actRegistrarse(ActionEvent event) {
        try{
           FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Registro.fxml"));
            Parent registerRoot = fxmlLoader.load();

            // Crear el nuevo escenario (ventana)
            Stage registerStage = new Stage();
            registerStage.setTitle("Registro de Usuario");
            registerStage.setScene(new Scene(registerRoot));
            registerStage.initModality(Modality.WINDOW_MODAL); // Bloquear interacción con la ventana principal
            registerStage.show();
        } catch (IOException e) {e.printStackTrace();}
    }

    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void actSalir(ActionEvent event) {
        Stage stage = (Stage) btSalir.getScene().getWindow();
        stage.close();
    }
    
}
